import React from 'react'

export default function ClientDetail() {
  return (
    <div>
      
    </div>
  )
}
