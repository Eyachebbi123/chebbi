import React from 'react'

export default function EmloyeesDetail() {
  return (
    <div>
      
    </div>
  )
}
